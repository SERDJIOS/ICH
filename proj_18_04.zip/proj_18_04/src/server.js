import express from 'express'
import dotenv from 'dotenv/config'
import sequelize from './config/db.js'
import User from './models/user.js'
import { use } from 'bcrypt/promises.js'


const app = express()
app.use(express.json())

const PORT = process.env.PORT || 3333

app.get('/', (req, res) =>{
  res.send('Hi sequelize')
})

app.post('/register', async (req,res) => {
  try { 
    const {name,username,email,password} = req.body
    if(!name || !username || !email || !password){
      res.status(400).json({error: 'All fields are required'})
      return
      
    }
    const newUser = await User.create({name,username,email,password})
    res.status(201).json({message: 'User was successfully created', user: newUser})
  } catch (error) {
    res.status(500).json({error: error})
  }
})

app.listen(PORT, async () =>{
  
    try {
      await sequelize.authenticate()
      console.log(`server successfully`);
      console.log(`server running on the PORT ${PORT}`);
      
      
  
  
    } catch (error) {
      console.log('unable to connect to the DB: ', error)
    }
})