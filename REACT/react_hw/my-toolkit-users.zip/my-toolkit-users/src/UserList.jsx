import React from "react";
import { useSelector } from "react-redux";

function UserList() {
  const users = useSelector((state) => state.users.users);

  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: "20px",
        justifyContent: "center",
      }}
    >
      {users.map((user) => (
        <div
          key={user.id}
          style={{
            backgroundColor: "#fdf",
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
            width: "220px",
            padding: "16px",
            textAlign: "center",
            transition: "transform 0.2s, box-shadow 0.2s",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.transform = "translateY(-3px)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.transform = "translateY(0)")
          }
        >
          <h3
            style={{
              margin: "0 0 10px",
              fontSize: "18px",
              color: "#324152",
              borderBottom: "1px solid #eee",
              paddingBottom: "8px",
            }}
          >
            {user.name}
          </h3>
          <p style={{ margin: "6px 0", color: "#555" }}>
            <strong>Age:</strong> {user.age}
          </p>
          <p style={{ margin: "6px 0", color: "#555" }}>
            <strong>City:</strong> {user.city}
          </p>
        </div>
      ))}
    </div>
  );
}

export default UserList;
